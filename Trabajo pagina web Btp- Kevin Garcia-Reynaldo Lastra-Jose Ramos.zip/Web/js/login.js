function signUp(){
    event.preventDefault();

    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    var username = document.getElementById('username').value;
    var tipo = document.getElementById('tipo').value;
    var documento = document.getElementById('documento').value;
    var pwd = document.getElementById('pwd').value;

    var user = {
        fname: fname,
        lname: lname,
        username: username,
        tipo: tipo,
        documento: documento,
        pwd: pwd,
    };

    var json = JSON.stringify(user);
    localStorage.setItem(username, json);
    console.log('user added');
    swal('¡Bien!','Su cuenta ha sido creada, ya puede iniciar sesión.','success');

}

function signIn(e){
    event.preventDefault();

    var username = document.getElementById('username').value;
    var pwd = document.getElementById('pwd').value;

    var user = localStorage.getItem(username);
    var data = JSON.parse(user);
    console.log(data);

    if(user == null){
        swal('Oops...','Este Usuario no se encuentra.','error');
    } else if(username == data.username && pwd == data.pwd){
        location.href = "html/paginapr.html";
    }else{
        swal('Oops...','Esta contraseña no es correcta.','error');
    }

}

function passvalues(){
    var inicio = document.getElementById("username").value;
    localStorage.setItem("textvalue", inicio);
    return false;
}