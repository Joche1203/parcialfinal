function RealizarPedido(){
    alert('¡FELICITACIONES! Su pedido ha sido realizado correctamente!')
}

function Registrar(){

    swal('Oops...','Por favor llene todos los campos para crear su cuenta satisfactoriamente','error');

}

/* Exportar a Excel Formulario de CONTACTENOS*/

document.getElementById('downloadexcel').addEventListener('click', function() {
    var table2excel = new Table2Excel();
    table2excel.export(document.querySelectorAll("#mitabla"));
  });



  /* Formulario de OONTACTENOS */

var divtabla=document.getElementById('cuadro')
        var i=1
        var botonenviar=document.getElementById('btnenviar')
        var botoneditar=document.getElementById('btneditar')
        botoneditar.disabled = true;

        var infoForm={}

        function procesar() {

          var nombre=document.getElementById('nombre').value
          var apellido=document.getElementById('apellido').value
          var correo=document.getElementById('correo').value
          var mensaje=document.getElementById('mensaje').value

          if(nombre=="" || apellido=="" || correo=="" || mensaje==""){
            swal('Oops...','Debe ingresar la información en todos los campos','error');
          }else{
            swal('¡Listo!','Sus datos han sido enviados correctamente','success');

            infoForm ["id"]= i++;
            infoForm ["nombre"]= nombre;
            infoForm ["apellido"]= apellido;
            infoForm ["correo"]= correo;
            infoForm ["mensaje"]= mensaje;

            var tabla = document.getElementById("mitabla");
            var nuevaFila = tabla.insertRow(tabla.length);

            cell1 = nuevaFila.insertCell(0);
            cell1.innerHTML = infoForm.id;

            cell2 = nuevaFila.insertCell(1);
            cell2.innerHTML = infoForm.nombre;

            cell3 = nuevaFila.insertCell(2);
            cell3.innerHTML = infoForm.apellido;

            cell4 = nuevaFila.insertCell(3);
            cell4.innerHTML = infoForm.correo;

            cell5 = nuevaFila.insertCell(4);
            cell5.innerHTML = infoForm.mensaje;

            cell5 = nuevaFila.insertCell(5);
            cell5.innerHTML = '<a class="btn btn-warning mx-S " onClick="onEdit(this)"><i class="bi bi-pencil-fill"></i></a> <a class= "btn btn-danger " onClick="onDelete(this)"><i class="bi bi-trash-fill"></i></a>' ;

            document.getElementById("miForm").reset();
            divtabla.style.display='';
          }
        }

        function onEdit(td){
          botoneditar.disabled = false;
          botonenviar.disabled = true;
          selectedRow = td.parentElement.parentElement;
          document.getElementById("nombre").value = selectedRow.cells[1].innerHTML;
          document.getElementById("apellido").value = selectedRow.cells[2].innerHTML;
          document.getElementById("correo").value = selectedRow.cells[3].innerHTML;
          document.getElementById("mensaje").value = selectedRow.cells[4].innerHTML;
        }

        function actualizarfila() {

          nombre=document.getElementById('nombre').value
          apellido=document.getElementById('apellido').value
          correo=document.getElementById('correo').value
          mensaje=document.getElementById('mensaje').value

          if(nombre=="" || apellido=="" || correo=="" || mensaje==""){
            swal('Oops...','Debe ingresar la información en todos los campos','error');
          }else{

            infoForm ["nombre"]= nombre;
            infoForm ["apellido"]= apellido;
            infoForm ["correo"]= correo;
            infoForm ["mensaje"]= mensaje;

            selectedRow.cells[1].innerHTML = infoForm.nombre;
            selectedRow.cells[2].innerHTML = infoForm.apellido;
            selectedRow.cells[3].innerHTML = infoForm.correo;
            selectedRow.cells[4].innerHTML = infoForm.mensaje;

            botoneditar.disabled = true;
            botonenviar.disabled = false
            swal('¡Bien!','La fila ha sido editada exitosamente','success');
            document.getElementById("miForm").reset();
          }
        }

        function onDelete(td){

          if (confirm('Estas seguro de esto? Si lo borras perderas la información')){

            row = td.parentElement.parentElement;
            document.getElementById("mitabla").deleteRow(row.rowIndex);

            var num = document.getElementById('mitabla').rows.length;

            if(num==1){
              divtabla.style.display='none';
            }
          }
        }


        


