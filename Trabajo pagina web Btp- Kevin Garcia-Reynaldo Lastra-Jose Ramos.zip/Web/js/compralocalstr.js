function local(){
    event.preventDefault();

    var metodo = document.getElementById('metodo').value;
    var nombre = document.getElementById('nombre').value;
    var numero = document.getElementById('numero').value;
    var expiracion = document.getElementById('expiracion').value;
    var cvv = document.getElementById('cvv').value;

    var user = {
        metodo: metodo,
        nombre: nombre,
        numero: numero,
        expiracion: expiracion,
        cvv: cvv,

    };

    var json = JSON.stringify(user);
    localStorage.setItem(nombre, json);
    console.log('payment method answ added');

}