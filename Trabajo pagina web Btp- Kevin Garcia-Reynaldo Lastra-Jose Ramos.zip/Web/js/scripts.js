const form = document.getElementById("transactionForm");

        form.addEventListener("submit", function(event) {
        event.preventDefault();
        let transactionFormData = new FormData(form);
        let transactionObj =convertFormDataToTransactionObj(transactionFormData)
        saveTransactionObj(transactionObj)
        insertRowInTransactionTable(transactionObj)
        form.reset();

        })
        
        document.addEventListener("DOMContentLoaded", function(event) {
          let transactionObjArr = JSON.parse(localStorage.getItem("transactionData"))
          transactionObjArr.forEach(
             function(arrayElement) { 
              insertRowInTransactionTable(arrayElement)
              console.log("Se inserta el elemento")
             
            }) 
        }
        )

        function convertFormDataToTransactionObj(transactionFormData) {
            let transactionType = transactionFormData.get("transactionType")
            let transactionName = transactionFormData.get("transactionName")
            let transactionLast = transactionFormData.get("transactionLast");
            let transactionEmail = transactionFormData.get("transactionEmail");
            let transactionCity = transactionFormData.get("transactionCity");
            let transactionMensaje = transactionFormData.get("transactionMensaje");
            return {
                "transactionType": transactionType, 
                "transactionName": transactionName, 
                "transactionLast": transactionLast, 
                "transactionEmail": transactionEmail, 
                "transactionCity": transactionCity,
                "transactionMensaje": transactionMensaje,
            }
        }
            
        function insertRowInTransactionTable(transactionObj) {

            let transactionTableRef = document.getElementById("transactionTable");
            let newTransactionRowRef = transactionTableRef.insertRow(-1);
            
            let newTypeCellRef = newTransactionRowRef.insertCell(0);
            newTypeCellRef.textContent = transactionObj["transactionType"];
    
            newTypeCellRef = newTransactionRowRef.insertCell(1);
            newTypeCellRef.textContent = transactionObj["transactionName"];
    
            newTypeCellRef = newTransactionRowRef.insertCell(2);
            newTypeCellRef.textContent = transactionObj["transactionLast"];

            newTypeCellRef = newTransactionRowRef.insertCell(3);
            newTypeCellRef.textContent = transactionObj["transactionEmail"];
    
            newTypeCellRef = newTransactionRowRef.insertCell(4);
            newTypeCellRef.textContent = transactionObj["transactionCity"];

            newTypeCellRef = newTransactionRowRef.insertCell(5);
            newTypeCellRef.textContent = transactionObj["transactionMensaje"];

            let newDeletCell = newTransactionRowRef.insertCell(6);
            let deleteButton = document.createElement("button");
            deleteButton.textContent = "Eliminar";
            newDeletCell.appendChild(deleteButton)

            deleteButton.addEventListener("click", (event) => {
                event.target.parentNode.parentNode.remove()
            })
            }
        
        function saveTransactionObj(transactionObj){
            let myTransactionArray = JSON.parse(localStorage.getItem("transactionData")) || [];
            myTransactionArray.push(transactionObj)
            let transactionArrayJSON = JSON.stringify(myTransactionArray);
            localStorage.setItem("transactionData", transactionArrayJSON)

        }