  /* Exportar a Excel Formulario de REGISTRO*/

  document.getElementById('downloadexcel2').addEventListener('click', function() {
    var table2excel = new Table2Excel();
    table2excel.export(document.querySelectorAll("#mitabla2"));
  });



  /* Formulario de REGISTRO */

  var divtabla=document.getElementById('cuadro2')
  var botonregistrar=document.getElementById('btnregistrar')
  var botoneditar=document.getElementById('btneditar')
  botoneditar.disabled = true;

  var infoForm={}

  function registrar() {

    var username=document.getElementById('username').value
    var fname=document.getElementById('fname').value
    var lname=document.getElementById('lname').value
    var documento=document.getElementById('documento').value
    var tipo=document.getElementById('tipo').value

    if(username=="" || fname=="" || lname=="" || documento=="" || tipo==""){
      swal('Oops...','Debe ingresar la información en todos los campos','error');
    }else{
      swal('¡Listo!','Sus datos han sido registrados exitosamente!','success');

      infoForm ["username"]= username;
      infoForm ["fname"]= fname;
      infoForm ["lname"]= lname;
      infoForm ["documento"]= documento;
      infoForm ["tipo"]= tipo;

      var tabla = document.getElementById("mitabla2");
      var nuevaFila = tabla.insertRow(tabla.length);

      cell1 = nuevaFila.insertCell(0);
      cell1.innerHTML = infoForm.username;

      cell2 = nuevaFila.insertCell(1);
      cell2.innerHTML = infoForm.fname;

      cell3 = nuevaFila.insertCell(2);
      cell3.innerHTML = infoForm.lname;

      cell4 = nuevaFila.insertCell(3);
      cell4.innerHTML = infoForm.documento;

      cell5 = nuevaFila.insertCell(4);
      cell5.innerHTML = infoForm.tipo;

      cell5 = nuevaFila.insertCell(5);
      cell5.innerHTML = '<a class="btn btn-warning mx-S " onClick="onEdit(this)"><i class="bi bi-pencil-fill"></i></a> <a class= "btn btn-danger " onClick="onDelete(this)"><i class="bi bi-trash-fill"></i></a>' ;

      document.getElementById("miForm2").reset();
      divtabla.style.display='';
    }
  }

  function onEdit(td){
    botoneditar.disabled = false;
    botonregistrar.disabled = true;
    selectedRow = td.parentElement.parentElement;
    document.getElementById("username").value = selectedRow.cells[0].innerHTML;
    document.getElementById("fname").value = selectedRow.cells[1].innerHTML;
    document.getElementById("lname").value = selectedRow.cells[2].innerHTML;
    document.getElementById("documento").value = selectedRow.cells[3].innerHTML;
    document.getElementById("tipo").value = selectedRow.cells[4].innerHTML;
  }

  function actualizarfila2() {

    username=document.getElementById('username').value
    fname=document.getElementById('fname').value
    lname=document.getElementById('lname').value
    documento=document.getElementById('documento').value
    tipo=document.getElementById('tipo').value

    if(username=="" || fname=="" || lname=="" || documento=="" || tipo==""){
      swal('Oops...','Debe ingresar la información en todos los campos','error');
    }else{

      infoForm ["username"]= username;
      infoForm ["fname"]= fname;
      infoForm ["lname"]= lname;
      infoForm ["documento"]= documento;
      infoForm ["tipo"]= tipo;

      selectedRow.cells[0].innerHTML = infoForm.username;
      selectedRow.cells[1].innerHTML = infoForm.fname;
      selectedRow.cells[2].innerHTML = infoForm.lname;
      selectedRow.cells[3].innerHTML = infoForm.documento;
      selectedRow.cells[4].innerHTML = infoForm.tipo;

      botoneditar.disabled = true;
      botonregistrar.disabled = false
      swal('¡Bien!','La fila ha sido editada exitosamente','success');
      document.getElementById("miForm2").reset();
    }
  }

  function onDelete(td){

    if (confirm('Estas seguro de esto? Si lo borras perderas la información')){

      row = td.parentElement.parentElement;
      document.getElementById("mitabla2").deleteRow(row.rowIndex);

      var num = document.getElementById('mitabla2').rows.length;

      if(num==1){
        divtabla.style.display='none';
      }
    }
  }