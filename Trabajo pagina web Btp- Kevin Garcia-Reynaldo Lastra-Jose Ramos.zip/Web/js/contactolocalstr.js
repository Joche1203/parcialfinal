function local(){
    event.preventDefault();

    var nombre = document.getElementById('nombre').value;
    var apellido = document.getElementById('apellido').value;
    var correo = document.getElementById('correo').value;
    var mensaje = document.getElementById('mensaje').value;

    var user = {
        nombre: nombre,
        apellido: apellido,
        correo: correo,
        mensaje: mensaje,

    };

    var json = JSON.stringify(user);
    localStorage.setItem(nombre, json);
    console.log('message form added');

}