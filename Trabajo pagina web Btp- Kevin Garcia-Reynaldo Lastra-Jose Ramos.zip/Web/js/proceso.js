var divtabla=document.getElementById('cuadro')
var i=1;
var botonenviar=document.getElementById('btnagregar')
var botoneditar=document.getElementById('btneditar')
botoneditar.disabled = true;


var infoForm={};


function procesar() {
var precio=document.getElementById('txtprecio').value
var cantidad=document.getElementById('txtcantidad').value
var producto=document.getElementById("txtproducto").value
var tipo=document.getElementById("selector"              
).value


if(precio=="" || cantidad==""){ 
alert("debe ingresar la informacion en todos los campos")
}else{
var total= parseFloat(precio)*parseFloat(cantidad);







var tabla = document.getElementById("mitabla");
var nuevaFila = tabla.insertRow(tabla.lenght);

cell1 = nuevaFila.insertCell(0);
cell1.innerHTML = i++;

cell2 = nuevaFila.insertCell(1);
cell2.innerHTML = producto;

cell3 = nuevaFila.insertCell(2);
cell3.innerHTML = tipo;

cell4 = nuevaFila.insertCell(3);
cell4.innerHTML = cantidad;

cell5 = nuevaFila.insertCell(4);
cell5.innerHTML = "$"+precio;

cell6 = nuevaFila.insertCell(5);
cell6.innerHTML = "$"+total;
 



document.getElementById("formulario").reset();
divtabla.style.display='';

}

}


function onEdit(td){
    botoneditar.disabled = false;
    botonenviar.disabled = true;
    selectedRow = td.parentElement.parentElement;
    document.getElementById("txtprecio").value = selectedRow.cells[1].innerHTML;
    document.getElementById("txtcantidad").value = selectedRow.cells[2].innerHTML;
}

function actualizarfila() {
    precio=document.getElementById('txtprecio').value
    cantidad=document.getElementById('txtcantidad').value
    if(precio=="" || cantidad==""){;
        alert("debe ingresar la informacion en todos los campos")
    }else{
         total= parseFloat(precio)*parseFloat(cantidad);
         infoForm ["precio"]= precio;
         infoForm ["cantidad"]= cantidad;
         infoForm ["total"]= total;

         selectedRow.cells[1].innerHTML = infoForm.precio;
         selectedRow.cells[2].innerHTML = infoForm.cantidad;
         selectedRow.cells[3].innerHTML = infoForm.total;
        
         botoneditar.disabled = true;
         botonenviar.disabled = false;
         alert("Fila editada exitosamente");
         document.getElementById("miForm").reset();
    }             
}





function onDelete(td){

    if (confirm('¿Estas seguro de esto?')){

        row = td.parentElement.parentElement;
        document.getElementById("mitabla").deleteRow(row.rowIndex);


        var num = document.getElementById('mitabla').rows.length;

        if(num==1){
            divtabla.style.display='none';
        }
    }
id
}